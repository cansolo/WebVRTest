
// In order for Chrome to consider this site a PWA, it must register a service worker.
// We are working on adding cache capabilities [1] but right now, it is provided empty.
// [1] https://github.com/mozilla/unity-webvr-export/issues/98 